这里是笔记

1.
    node_modules文件夹：项目依赖文件夹

    public文件夹：放置静态资源，webpack打包时原封不动打包到dist文件夹中

    src文件夹（程序员源代码）：

        assets文件夹：放置静态资源（多组件公用的静态资源），打包时会把静态资源打包js文件里面

        components文件夹：放非路由组件

        app.vue 根组件
        main.js 程序入口文件

    babel.config.js配置文件

    package.json 记录项目叫什么、项目当中有哪些依赖、项目运行

    package-lock.json缓存性文件

2.
    项目运行让浏览器自动打开
    ---package.json{
        "serve":"vue-cli-service serve -- open",
        "build":"vue-cli-service build",
        "lint":"vue-cli-service lint"
    }

    eslint校验功能关闭
    ---vue.config.js

3.
    $route：一般获取路由信息【路径、query、params】
    ￥router：一般进行编程式导航进行路由跳转【push、replace】

    router-link声明式跳转
    push、replac编程式跳转

4.
    路由传参
    params：属于路径当中一部分，配置路由的时候需要占位
    query：不属于路径当中一部分，不需要占位

5.
    防抖：前面的所有的触发都被取消最后一次执行在规定的时间之后才会触发，也就是如果连续快速触发只会执行一次

    节流：在规定的间隔时间范围内不会重复触发回调，只有大于这个时间间隔才会触发回调，把频繁触发变为少量触发

    